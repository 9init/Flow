package flow.emovent.com.modules

import java.io.File

data class FileData(val file: File)


